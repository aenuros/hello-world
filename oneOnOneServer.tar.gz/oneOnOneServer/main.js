/*
const express=require('express');
const app = express();
app.listen(5000, () => {
  console.log('Listening on port 5000');
});
app.use(express.static(__dirname));
app.get('/', (request,response) => {
console.log("hi");
  response.send("hello wlr");
});
*/

let menuItems = [];

let MenuItem = class {
  constructor(priceInCents,name) {
    this.priceInCents = priceInCents,
    this.name = name,
    this.addMenuItem = function addMenuItem () {
      menuItems.push(this);
    }
    this.addMenuItem();
  }
  get usd() {
    return(((this.priceInCents)/100).toLocaleString('en-US'));
  }

};

let beetSalad = new MenuItem(425,"beet salad");

console.log(beetSalad.priceInCents);
console.log(beetSalad.usd);


class Sandwich extends MenuItem {
  constructor(...args) {
    super(...args),
    this.ingredientList = []
  }
  set addIngredients(ingredients) {

    let newIngr = ingredients.split(",");
    this.ingredientList.push(...newIngr);
  }
  BestSandwich() {
    console.log("My sandwiches are healthy and gluten free!")
  }
  get webListIngredients() {
    let htmlString = "";
      for (i=0;i<this.ingredientList.length;i++){
        htmlString= `<li>${this.ingredientList[i]}</li>`;
      }
  }
}

let ruben= new Sandwich(444,"Ruben");

//console.log(ruben);
ruben.BestSandwich();
ruben.addIngredients = "lettuce,tomato";

console.log(ruben);



let hamcheese = new Sandwich(750,"ham and cheese");
hamcheese.addIngredients = "ham,provolone,lettuce,tomatoes,mayo";


console.log(menuItems);
