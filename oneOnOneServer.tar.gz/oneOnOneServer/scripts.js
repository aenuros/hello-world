$(document).ready(function(){

$(".flip-container").on("click", function () {

  $.get("/details/1", function(data, status){
      alert("Data: " + data + "\nStatus: " + status);
  });

  $.ajax({
      url:'http://api.icndb.com/jokes/random',
      dataType: 'json'
    }).done((result) => {
          $("#conversation").append(`<li>hi</li>`);
    });

});

});
